
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import DonationGoalBar from "@/components/live/DonationGoalBar";

export default function LiveDonationGoal({ streamId, goal }) {
  const [raised, setRaised] = useState(0);

  useEffect(() => {
    if (!streamId) return;
    let active = true;

    const load = async () => {
      const { rows } = await base44.entities.Donation.aggregate({
        query: { stream_id: streamId, status: "paid" },
        sum: "amount",
      }).catch(() => ({ rows: [] }));
      if (active) setRaised(rows[0]?.sum_amount || 0);
    };

    load();
    const unsubscribe = base44.entities.Donation.subscribe((event) => {
      if (event.data?.stream_id === streamId) load();
    });

    return () => {
      active = false;
      unsubscribe();
    };
  }, [streamId]);

  return (
    <div className="bg-secondary/40 rounded-2xl p-3">
      <DonationGoalBar goal={goal} raised={raised} />
    </div>
  );
}


