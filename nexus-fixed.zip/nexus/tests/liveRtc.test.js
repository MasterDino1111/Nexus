import { describe, it, expect } from "vitest";
import { buildIceServers } from "../src/lib/liveRtc.js";

describe("buildIceServers", () => {
  it("uses STUN only by default", () => {
    const s = buildIceServers({});
    expect(s.every((x) => String(x.urls).startsWith("stun:"))).toBe(true);
  });
  it("adds a TURN relay when configured", () => {
    const s = buildIceServers({ VITE_TURN_URL: "turn:a.example:3478, turns:a.example:5349", VITE_TURN_USERNAME: "u", VITE_TURN_CREDENTIAL: "p" });
    const turn = s.at(-1);
    expect(turn.urls).toEqual(["turn:a.example:3478", "turns:a.example:5349"]);
    expect(turn.username).toBe("u");
  });
});
